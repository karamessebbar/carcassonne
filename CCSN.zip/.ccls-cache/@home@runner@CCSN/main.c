#include <stdio.h>

int main(void) {
	printf("\xB1]31mHello World\n");
	return 0;
}